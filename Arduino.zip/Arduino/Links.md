LCD
https://www.youtube.com/watch?v=cXpeTxC3_A4


https://www.youtube.com/watch?v=Gd6GUsHL4FI
